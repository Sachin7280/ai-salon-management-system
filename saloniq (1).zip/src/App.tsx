import { createBrowserRouter, Navigate, Outlet, RouterProvider, useLocation, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';
import { useProfileStore } from './store';
import { Home, Calendar as CalendarIcon, User, PlusCircle, Linkedin } from 'lucide-react';
import { cn } from './utils';
import { useEffect, useState } from 'react';

// Import Screens here
import OnboardingScreen from './screens/OnboardingScreen';
import HomeScreen from './screens/HomeScreen';
import ProfileScreen from './screens/ProfileScreen';
import AppointmentsScreen from './screens/AppointmentsScreen';
import BookingWizard from './screens/BookingWizard';
import CalendarScreen from './screens/CalendarScreen';
import RescheduleScreen from './screens/RescheduleScreen';
import ChatbotWidget from './components/ChatbotWidget';

function ProtectedRoute() {
  const onboarded = useProfileStore(s => s.onboarded);
  if (!onboarded) {
    return <Navigate to="/" replace />;
  }
  return <Outlet />;
}

function MainLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const profile = useProfileStore(s => s.profile);
  
  const isBookingFlow = location.pathname.startsWith('/app/book');
  const isCalendar = location.pathname.startsWith('/app/calendar');
  const isReschedule = location.pathname.startsWith('/app/reschedule');
  
  const hideBottomNav = isBookingFlow || isCalendar || isReschedule;

  return (
    <div className="w-full h-full bg-[#F8F7F4] text-zinc-900 overflow-hidden flex flex-col md:flex-row relative">
      {/* Sidebar for Desktop - Hidden on Mobile */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-zinc-200 shrink-0 h-full p-6 justify-between z-40">
        <div className="space-y-8">
          {/* Logo */}
          <div className="flex items-center gap-3 px-2">
            <div className="w-10 h-10 bg-brand rounded-xl rotate-45 flex items-center justify-center shadow-lg shadow-brand/20">
              <div className="-rotate-45 text-white font-bold text-lg">S</div>
            </div>
            <span className="font-bold text-xl tracking-tight text-zinc-900">SalonIQ</span>
          </div>

          {/* Menu Items */}
          <nav className="flex flex-col gap-1.5">
            <SidebarItem path="/app/home" icon={Home} label="Home Dashboard" current={location.pathname} navigate={navigate} />
            <SidebarItem path="/app/book/service" icon={PlusCircle} label="Book Appointment" current={location.pathname} navigate={navigate} />
            <SidebarItem path="/app/appointments" icon={CalendarIcon} label="My Bookings" current={location.pathname} navigate={navigate} />
            <SidebarItem path="/app/profile" icon={User} label="Profile & Settings" current={location.pathname} navigate={navigate} />
          </nav>
        </div>

        {/* Profile card at bottom of Sidebar */}
        {profile && (
          <div className="p-4 bg-zinc-50 border border-zinc-100 rounded-2xl flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-brand/10 flex items-center justify-center text-brand font-bold text-sm shrink-0">
              {profile.name[0]}
            </div>
            <div className="min-w-0 overflow-hidden flex-1">
              <p className="font-semibold text-zinc-900 text-sm truncate">{profile.name}</p>
              <p className="text-zinc-500 text-xs truncate">{profile.phone}</p>
            </div>
          </div>
        )}
      </aside>

      {/* Main Container */}
      <div className={cn(
        "flex-1 flex flex-col h-full bg-background overflow-hidden relative"
      )}>
        <div className={cn(
          "w-full h-full flex flex-col bg-background relative overflow-hidden",
          "max-w-md mx-auto shadow-2xl",
          "md:max-w-none md:mx-0 md:shadow-none md:my-0 md:h-full md:rounded-none md:border-0"
        )}>
          {/* Main Content Area */}
          <div className="flex-1 overflow-hidden relative">
             <Outlet />
          </div>

          {/* Floating Chat widget - above tabs */}
          {!hideBottomNav && <ChatbotWidget />}

          {/* Bottom Tab Bar (Mobile Only) */}
          {!hideBottomNav && (
            <div className="h-16 bg-white border-t border-zinc-200 grid grid-cols-4 items-center px-2 pb-safe absolute bottom-0 w-full z-40 md:hidden">
              <TabItem path="/app/home" icon={Home} label="Home" current={location.pathname} navigate={navigate} />
              <TabItem path="/app/book/service" icon={PlusCircle} label="Book" current={location.pathname} navigate={navigate} />
              <TabItem path="/app/appointments" icon={CalendarIcon} label="Visits" current={location.pathname} navigate={navigate} />
              <TabItem path="/app/profile" icon={User} label="Profile" current={location.pathname} navigate={navigate} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function SidebarItem({ path, icon: Icon, label, current, navigate }: any) {
  const isActive = current === path || 
    (path === '/app/book/service' && current.startsWith('/app/book')) ||
    (path === '/app/appointments' && current.startsWith('/app/reschedule')) ||
    (path !== '/app/book/service' && path !== '/app/appointments' && current.startsWith(path));
  return (
    <button 
      onClick={() => navigate(path)}
      className={cn(
        "flex items-center gap-3.5 px-4 h-12 w-full rounded-xl font-medium text-sm transition-all",
        isActive 
          ? "bg-brand text-white shadow-md shadow-brand/10 font-semibold" 
          : "text-zinc-600 hover:bg-zinc-100 hover:text-zinc-900"
      )}
    >
      <Icon size={20} className={isActive ? "text-white" : "text-zinc-400"} />
      <span>{label}</span>
    </button>
  );
}

function TabItem({ path, icon: Icon, label, current, navigate }: any) {
  // If we match exactly the path or starting pattern, activate.
  const isActive = current === path || (path !== '/app/book/service' && current.startsWith(path));
  return (
    <button 
      onClick={() => navigate(path)}
      className={cn("flex flex-col items-center justify-center space-y-1 h-full w-full", isActive ? "text-brand" : "text-zinc-400")}
    >
      <Icon size={22} className={isActive ? "fill-brand/20" : ""} />
      <span className="text-[10px] font-medium">{label}</span>
    </button>
  );
}

function getOuterBg(pathname: string): string {
  if (pathname === '/' || pathname === '') {
    return 'bg-[#FAF6F0]'; // Elegant peach/linen
  }
  if (pathname.includes('/book')) {
    return 'bg-[#EFF2F6]'; // Sleek aesthetic slate blue
  }
  if (pathname.includes('/appointments') || pathname.includes('/reschedule')) {
    return 'bg-[#FAF5FB]'; // Warm rich lavender tint
  }
  if (pathname.includes('/profile')) {
    return 'bg-[#ECEFF1]'; // Cozy cloud grey
  }
  if (pathname.includes('/home')) {
    return 'bg-[#F2EDF7]'; // High-end elegant pale orchid
  }
  return 'bg-[#FAF6F0]';
}

function getScreenDisplayName(pathname: string): string {
  if (pathname === '/' || pathname === '') {
    return 'Onboarding';
  }
  if (pathname.includes('/book/service')) {
    return 'Choose Service';
  }
  if (pathname.includes('/book/stylist')) {
    return 'Select Stylist';
  }
  if (pathname.includes('/book/date')) {
    return 'Select Date & Time';
  }
  if (pathname.includes('/book/confirm')) {
    return 'Booking Confirmed';
  }
  if (pathname.includes('/book')) {
    return 'Book Appointment';
  }
  if (pathname.includes('/appointments')) {
    return 'My Bookings';
  }
  if (pathname.includes('/reschedule')) {
    return 'Reschedule Booking';
  }
  if (pathname.includes('/profile')) {
    return 'Profile & Settings';
  }
  if (pathname.includes('/calendar')) {
    return 'Calendar View';
  }
  if (pathname.includes('/home')) {
    return 'Home Dashboard';
  }
  return 'SalonIQ';
}

function ArtboardWrapper() {
  const location = useLocation();
  const [scale, setScale] = useState(1);

  useEffect(() => {
    const handleResize = () => {
      // The design workspace coordinates are fixed: Width = 1747px, Height = 1094px
      const scaleW = (window.innerWidth - 32) / 1747;
      const scaleH = (window.innerHeight - 32) / 1094;
      const newScale = Math.min(1, Math.min(scaleW, scaleH));
      setScale(newScale);
    };
    
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const outerBgClass = getOuterBg(location.pathname);

  return (
    <div className={cn(
      "h-screen w-screen overflow-hidden flex items-center justify-center transition-colors duration-500 ease-in-out select-none",
      outerBgClass
    )}>
      {/* Scalable Container wrapper */}
      <div 
        style={{
          transform: `scale(${scale})`,
          transformOrigin: 'center center',
          width: '1747px',
          height: '1094px',
        }}
        className="flex flex-col items-center justify-between flex-shrink-0 transition-transform duration-300 ease-out"
      >
        {/* Top Title Banner */}
        <header className="h-[96px] w-full flex flex-col items-center justify-center select-none shrink-0 pt-2">
          <h1 className="font-cursive text-5xl leading-none text-zinc-800 tracking-wide drop-shadow-sm select-none -mt-4">
            Type "Code" For Code
          </h1>
          <div className="font-sans text-[13px] font-bold uppercase tracking-[0.16em] text-zinc-650 mt-2.5 flex items-center justify-center gap-1.5 leading-none h-5">
            <span className="text-zinc-500">AI Powered Salon Booking System</span>
            <span className="text-zinc-300 font-light mx-0.5">|</span>
            <div className="inline-block relative overflow-hidden h-5 min-w-[200px]">
              <AnimatePresence mode="wait">
                <motion.span
                  key={location.pathname}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2, ease: "easeOut" }}
                  className="text-brand font-extrabold tracking-widest absolute left-0 top-0 whitespace-nowrap"
                >
                  {getScreenDisplayName(location.pathname)}
                </motion.span>
              </AnimatePresence>
            </div>
          </div>
        </header>

        {/* The 1747 x 942 Elevated Artboard Workspace */}
        <main 
          style={{
            boxShadow: '0 40px 90px -20px rgba(0, 0, 0, 0.45), 0 20px 40px -15px rgba(0, 0, 0, 0.3), 0 0 0 1px rgba(0, 0, 0, 0.08), inset 0 1px 2px rgba(255, 255, 255, 0.25)',
          }}
          className="w-[1747px] h-[942px] bg-white rounded-3xl overflow-hidden relative border border-zinc-200/50 flex-shrink-0"
        >
          <Outlet />
        </main>

        {/* Signature Branded Footer */}
        <footer className="h-[56px] w-full flex items-center justify-center shrink-0">
          <a 
            href="https://linkedin.com/in/letssachin" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-3.5 px-6 py-2 bg-zinc-900 border border-zinc-800/80 hover:bg-zinc-850 hover:border-zinc-700 rounded-full text-white hover:scale-105 duration-300 transition-all font-semibold uppercase tracking-widest text-xs shadow-md shadow-black/20"
          >
            <div className="w-6 h-6 rounded-full bg-zinc-800 flex items-center justify-center">
              <Linkedin size={13} className="text-white fill-white" />
            </div>
            <span>@letssachin</span>
          </a>
        </footer>
      </div>
    </div>
  );
}

const router = createBrowserRouter([
  {
    path: '/',
    element: <ArtboardWrapper />,
    children: [
      {
        path: '',
        element: <RootRedirect />
      },
      {
        path: 'app',
        element: <ProtectedRoute />,
        children: [
          {
            element: <MainLayout />,
            children: [
              { path: 'home', element: <HomeScreen /> },
              { path: 'profile', element: <ProfileScreen /> },
              { path: 'appointments', element: <AppointmentsScreen /> },
              { path: 'calendar', element: <CalendarScreen /> },
              { path: 'reschedule/:id', element: <RescheduleScreen /> },
              { path: 'book/*', element: <BookingWizard /> },
            ]
          }
        ]
      }
    ]
  }
]);

function RootRedirect() {
  const onboarded = useProfileStore(s => s.onboarded);
  return onboarded ? <Navigate to="/app/home" replace /> : <OnboardingScreen />;
}

export default function App() {
  return <RouterProvider router={router} />;
}
