import clsx, { ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Generate random ID client-side
import { v4 as uuidv4 } from 'uuid';
export function generateId() {
  return uuidv4();
}
