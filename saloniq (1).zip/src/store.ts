import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Appointment, ClientProfile, ChatMessage } from './types';

// Client Profile
interface ProfileState {
  profile: ClientProfile | null;
  onboarded: boolean;
  setProfile: (p: ClientProfile) => void;
  setOnboarded: (val: boolean) => void;
  clearProfile: () => void;
}

export const useProfileStore = create<ProfileState>()(
  persist(
    (set) => ({
      profile: null,
      onboarded: false,
      setProfile: (profile) => set({ profile }),
      setOnboarded: (onboarded) => set({ onboarded }),
      clearProfile: () => set({ profile: null, onboarded: false }),
    }),
    { name: 'salon_client_v1' }
  )
);

// Appointments
interface AppointmentsState {
  appointments: Appointment[];
  addAppointment: (app: Appointment) => void;
  updateAppointmentStatus: (id: string, status: Appointment['status']) => void;
  rescheduleAppointment: (id: string, newDate: string, newTime: string, newEndTime: string) => void;
  clearAll: () => void;
}

export const useAppointmentsStore = create<AppointmentsState>()(
  persist(
    (set) => ({
      appointments: [],
      addAppointment: (app) => set((state) => ({ appointments: [...state.appointments, app] })),
      updateAppointmentStatus: (id, status) => set((state) => ({
        appointments: state.appointments.map(a => a.id === id ? { ...a, status } : a)
      })),
      rescheduleAppointment: (id, newDate, newTime, newEndTime) => set((state) => ({
        appointments: state.appointments.map(a => a.id === id ? { ...a, date: newDate, startTime: newTime, endTime: newEndTime } : a)
      })),
      clearAll: () => set({ appointments: [] })
    }),
    { name: 'salon_appointments' }
  )
);

// Booking Form Wizard Draft
interface BookingDraft {
  serviceId?: string;
  stylistId?: string;
  date?: string;
  slotId?: string;
  startTime?: string;
  endTime?: string;
  notes?: string;
}

interface BookingState {
  draft: BookingDraft;
  updateDraft: (updates: Partial<BookingDraft>) => void;
  clearDraft: () => void;
}

export const useBookingStore = create<BookingState>()(
  persist(
    (set) => ({
      draft: {},
      updateDraft: (updates) => set((state) => ({ draft: { ...state.draft, ...updates } })),
      clearDraft: () => set({ draft: {} })
    }),
    { name: 'salon_booking_draft' }
  )
);

// WhatsApp Logs Simulator
interface WhatsAppLog {
  id: string;
  timestamp: string;
  message: string;
}

interface MetaState {
  whatsappLogs: WhatsAppLog[];
  addLog: (msg: string) => void;
  clearLogs: () => void;
}

export const useMetaStore = create<MetaState>()(
  persist(
    (set) => ({
      whatsappLogs: [],
      addLog: (msg) => set((state) => ({
        whatsappLogs: [{ id: Date.now().toString(), timestamp: new Date().toISOString(), message: msg }, ...state.whatsappLogs]
      })),
      clearLogs: () => set({ whatsappLogs: [] })
    }),
    { name: 'salon_meta' }
  )
);

// Chat History
interface ChatStoreState {
  messages: ChatMessage[];
  addMessage: (msg: ChatMessage) => void;
  clearMessages: () => void;
}
export const useChatStore = create<ChatStoreState>()(
  persist(
    (set) => ({
      messages: [],
      addMessage: (msg) => set((state) => ({ messages: [...state.messages, msg].slice(-20) })), // KEEP LAST 20
      clearMessages: () => set({ messages: [] })
    }),
    { name: 'salon_chat_history' }
  )
);
