import { useProfileStore, useAppointmentsStore, useMetaStore } from '../store';
import { cn } from '../utils';
import { Settings, LogOut, CheckCircle, Smartphone } from 'lucide-react';

export default function ProfileScreen() {
  const profile = useProfileStore(s => s.profile);
  const clearProfile = useProfileStore(s => s.clearProfile);
  const clearAppointments = useAppointmentsStore(s => s.clearAll);
  const { whatsappLogs, clearLogs } = useMetaStore(s => s);

  const appointments = useAppointmentsStore(s => s.appointments);
  const totalBookings = appointments.length;

  const handleClearData = () => {
    if (confirm("Are you sure you want to clear all app data?")) {
      clearProfile();
      clearAppointments();
      clearLogs();
    }
  };

  if (!profile) return null;

  return (
    <div className="flex flex-col h-full w-full bg-background overflow-y-auto pb-24">
      <div className="max-w-4xl mx-auto w-full min-h-full bg-background border-x border-zinc-100 flex flex-col">
        {/* Header Profile */}
        <div className="bg-white p-6 pt-10 border-b border-zinc-100 flex flex-col items-center">
        <div className="w-20 h-20 bg-brand text-white rounded-full flex items-center justify-center font-bold text-3xl mb-4 shadow-xl shadow-brand/20">
          {profile.name[0]}
        </div>
        <h1 className="text-2xl font-bold tracking-tight text-zinc-900">{profile.name}</h1>
        <p className="text-zinc-500 mt-1">{profile.phone}</p>
        
        <div className="flex gap-4 mt-8 w-full">
           <div className="flex-1 bg-zinc-50 rounded-2xl p-4 text-center border border-zinc-100">
             <div className="text-2xl font-bold text-zinc-900">{totalBookings}</div>
             <div className="text-xs font-medium text-zinc-500 uppercase tracking-wider mt-1">Bookings</div>
           </div>
           <div className="flex-1 bg-zinc-50 rounded-2xl p-4 text-center border border-zinc-100">
             <div className="text-2xl font-bold text-zinc-900">{profile.preferences.timeOfDay}</div>
             <div className="text-xs font-medium text-zinc-500 uppercase tracking-wider mt-1">Pref Time</div>
           </div>
        </div>
      </div>

      {/* WhatsApp Simulator Log */}
      <div className="p-6">
        <h2 className="text-sm font-semibold text-zinc-900 mb-4 px-1 uppercase tracking-wider">WhatsApp Notifications (Simulator)</h2>
        <div className="bg-white rounded-3xl border border-zinc-200 overflow-hidden">
          {whatsappLogs.length === 0 ? (
            <div className="p-8 text-center text-zinc-500 text-sm">No messages yet.</div>
          ) : (
            whatsappLogs.slice(0, 5).map((log, i) => (
              <div key={log.id} className={cn("p-4 flex gap-3", i !== 0 && "border-t border-zinc-100")}>
                <div className="mt-0.5"><div className="w-8 h-8 rounded-full bg-[#25D366]/10 flex items-center justify-center"><CheckCircle size={16} className="text-[#25D366]" /></div></div>
                <div>
                  <p className="text-sm text-zinc-900">{log.message}</p>
                  <p className="text-xs text-zinc-400 mt-1 font-mono">{new Date(log.timestamp).toLocaleTimeString()}</p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      <div className="p-6 pt-2">
        <h2 className="text-sm font-semibold text-zinc-900 mb-4 px-1 uppercase tracking-wider">App Settings</h2>
        
        <div className="bg-white rounded-3xl border border-zinc-200 overflow-hidden mb-6 flex flex-col">
           <button 
             onClick={() => {
                // mock PWA prompt
                alert('PWA install prompt would trigger here');
             }} 
             className="w-full flex items-center justify-between p-4 bg-white border-b border-zinc-100 active:bg-zinc-50"
           >
             <div className="flex items-center gap-3">
               <div className="w-10 h-10 bg-zinc-100 rounded-full flex items-center justify-center"><Smartphone size={18} className="text-zinc-600" /></div>
               <span className="font-medium text-zinc-900">Install App</span>
             </div>
           </button>
           <button 
             onClick={handleClearData} 
             className="w-full flex items-center justify-between p-4 bg-white active:bg-red-50"
           >
             <div className="flex items-center gap-3">
               <div className="w-10 h-10 bg-red-50 rounded-full flex items-center justify-center text-red-600"><LogOut size={18} /></div>
               <span className="font-medium text-red-600">Clear Data & Reset</span>
             </div>
           </button>
        </div>
      </div>
      </div>
    </div>
  );
}
