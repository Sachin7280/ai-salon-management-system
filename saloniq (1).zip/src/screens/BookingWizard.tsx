import React, { useEffect } from 'react';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft } from 'lucide-react';
import { useBookingStore, useProfileStore } from '../store';
import { cn } from '../utils';

// Sub-screens
import ServiceStep from './booking/ServiceStep';
import StylistStep from './booking/StylistStep';
import DateStep from './booking/DateStep';
import SlotStep from './booking/SlotStep';
import DetailsStep from './booking/DetailsStep';
import ConfirmStep from './booking/ConfirmStep';

const steps = [
  { path: 'service', title: 'Select Service', weight: 1 },
  { path: 'stylist', title: 'Select Stylist', weight: 2 },
  { path: 'date', title: 'Pick a Date', weight: 3 },
  { path: 'slot', title: 'Pick a Time', weight: 4 },
  { path: 'details', title: 'Your Details', weight: 5 },
  { path: 'confirm', title: 'Confirm', weight: 6 }
];

export default function BookingWizard() {
  const location = useLocation();
  const navigate = useNavigate();
  const clearDraft = useBookingStore(s => s.clearDraft);
  
  // Auto redirect to service if base route
  useEffect(() => {
    if (location.pathname === '/app/book') {
      navigate('/app/book/service', { replace: true });
    }
  }, [location, navigate]);

  const currentStep = steps.find(s => location.pathname.includes(s.path)) || steps[0];
  const progress = (currentStep.weight / steps.length) * 100;
  
  // Custom back handler
  const handleBack = () => {
    if (currentStep.weight === 1) {
      clearDraft();
      navigate('/app/home');
    } else if (currentStep.weight === 6) {
      navigate('/app/home');
    } else {
      navigate(-1);
    }
  };

  return (
    <div className="flex flex-col h-full bg-white relative">
      {/* Top Bar inside wizard */}
      <div className="h-14 flex items-center px-4 relative z-10 bg-white">
        {currentStep.weight < 6 && (
          <button onClick={handleBack} className="p-2 -ml-2 text-zinc-900 absolute left-4 active:bg-zinc-100 rounded-full">
            <ChevronLeft size={24} />
          </button>
        )}
        <h1 className="text-center w-full font-semibold text-lg">{currentStep.title}</h1>
      </div>
      
      {/* Progress Bar */}
      {currentStep.weight < 6 && (
        <div className="h-1 w-full bg-zinc-100 relative z-10">
          <div className="h-full bg-brand transition-all duration-300" style={{ width: `${progress}%` }} />
        </div>
      )}

      {/* Steps Content Area */}
      <div className="flex-1 relative overflow-hidden bg-background">
        <AnimatePresence mode="wait">
          <Routes location={location}>
            <Route path="service" element={<PageWrapper><ServiceStep /></PageWrapper>} />
            <Route path="stylist" element={<PageWrapper><StylistStep /></PageWrapper>} />
            <Route path="date" element={<PageWrapper><DateStep /></PageWrapper>} />
            <Route path="slot" element={<PageWrapper><SlotStep /></PageWrapper>} />
            <Route path="details" element={<PageWrapper><DetailsStep /></PageWrapper>} />
            <Route path="confirm" element={<PageWrapper><ConfirmStep /></PageWrapper>} />
          </Routes>
        </AnimatePresence>
      </div>
    </div>
  );
}

function PageWrapper({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      transition={{ duration: 0.22, ease: "easeInOut" }}
      className="absolute inset-0 overflow-y-auto"
    >
       {children}
    </motion.div>
  );
}
