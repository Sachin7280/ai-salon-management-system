import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useProfileStore } from '../store';
import { cn } from '../utils';

export default function OnboardingScreen() {
  const [step, setStep] = useState(1);
  const setOnboarded = useProfileStore(s => s.setOnboarded);
  const setProfile = useProfileStore(s => s.setProfile);

  useEffect(() => {
    if (step === 1) {
      const timer = setTimeout(() => setStep(2), 2000);
      return () => clearTimeout(timer);
    }
  }, [step]);

  return (
    <div className="w-full h-full flex flex-col items-center justify-center bg-background absolute inset-0 z-50">
      <AnimatePresence mode="wait">
        {step === 1 && (
          <motion.div
            key="splash"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 1.1, opacity: 0 }}
            transition={{ duration: 0.6 }}
            className="flex flex-col items-center gap-4"
          >
            <div className="w-20 h-20 bg-brand rounded-2xl rotate-45 flex items-center justify-center shadow-2xl">
               <div className="-rotate-45 text-white font-bold text-3xl">S</div>
            </div>
            <h1 className="text-2xl font-semibold tracking-tight text-zinc-900 mt-2">SalonIQ</h1>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div
            key="carousel"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="w-full flex-1 flex flex-col"
          >
            <div className="flex-1 flex flex-col justify-end p-8 pb-12">
              <h2 className="text-3xl font-bold tracking-tight text-zinc-900 leading-tight">Book in <br/><span className="text-brand">60 seconds</span></h2>
              <p className="mt-4 text-zinc-500 text-lg">AI finds your best slot and reminds you via WhatsApp.</p>
              
              <button 
                onClick={() => setStep(3)}
                className="mt-12 w-full bg-zinc-900 text-white h-14 rounded-2xl font-medium text-lg active:scale-95 transition-transform"
              >
                Get Started
              </button>
            </div>
          </motion.div>
        )}

        {step === 3 && (
          <motion.div
            key="profile"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="w-full h-full bg-white flex flex-col p-6 pt-16"
          >
            <h2 className="text-2xl font-bold mb-8">Let's set up your profile</h2>
            
            <form onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              const name = fd.get('name') as string;
              const phone = fd.get('phone') as string;
              const timeOfDay = fd.get('timeOfDay') as any;
              
              setProfile({
                id: Date.now().toString(),
                name,
                phone: '+91' + phone,
                preferences: { timeOfDay, whatsappOptIn: true }
              });
              setOnboarded(true);
            }} className="flex-1 flex flex-col gap-6">
              
              <div>
                <label className="text-sm font-medium text-zinc-700">Full Name</label>
                <input required name="name" type="text" className="w-full mt-2 h-12 px-4 rounded-xl border border-zinc-200 outline-none focus:border-brand focus:ring-1 focus:ring-brand" placeholder="e.g. Priya Sharma" />
              </div>

              <div>
                <label className="text-sm font-medium text-zinc-700">Mobile Number</label>
                <div className="flex mt-2">
                  <div className="h-12 px-4 bg-zinc-100 flex items-center rounded-l-xl border border-zinc-200 border-r-0 text-zinc-500 font-medium">+91</div>
                  <input required name="phone" pattern="^[6-9]\d{9}$" type="tel" className="w-full h-12 px-4 rounded-r-xl border border-zinc-200 outline-none focus:border-brand focus:ring-1 focus:ring-brand" placeholder="9876543210" />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-zinc-700 block mb-2">Preferred Time</label>
                <div className="grid grid-cols-3 gap-2">
                  {['Morning', 'Afternoon', 'Evening'].map(time => (
                    <label key={time} className="cursor-pointer">
                      <input type="radio" name="timeOfDay" value={time} defaultChecked={time === 'Morning'} className="peer sr-only" />
                      <div className="h-12 flex items-center justify-center rounded-xl border border-zinc-200 text-sm font-medium peer-checked:bg-brand peer-checked:text-white peer-checked:border-brand transition-colors">
                        {time}
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              <div className="mt-auto pb-safe">
                <button type="submit" className="w-full bg-brand text-white h-14 rounded-2xl font-medium text-lg active:scale-95 transition-transform">
                  Continue
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
