import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useBookingStore } from '../../store';
import { cn } from '../../utils';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { format, addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, isBefore, startOfDay, addDays } from 'date-fns';

export default function DateStep() {
  const navigate = useNavigate();
  const selectedDateStr = useBookingStore(s => s.draft.date);
  const updateDraft = useBookingStore(s => s.updateDraft);
  
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const today = startOfDay(new Date());

  const handleSelect = (date: Date) => {
    if (isBefore(date, today)) return;
    updateDraft({ date: format(date, 'yyyy-MM-dd') });
    navigate('../slot'); // auto advance
  };

  const nextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));
  const prevMonth = () => setCurrentMonth(subMonths(currentMonth, 1));

  const start = startOfMonth(currentMonth);
  const end = endOfMonth(currentMonth);
  
  // padding to start on Monday (1)
  const startDay = start.getDay();
  const diff = startDay === 0 ? 6 : startDay - 1; 
  const firstDayOfGrid = subDays(start, diff);
  
  const days = eachDayOfInterval({ start: firstDayOfGrid, end: addDays(end, 42 - (eachDayOfInterval({start: firstDayOfGrid, end}).length)) });

  function subDays(date: Date, amount: number): Date {
    return addDays(date, -amount);
  }

  return (
    <div className="p-4 md:p-8 bg-white h-full max-w-xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <button onClick={prevMonth} className="p-2 active:bg-zinc-100 rounded-full"><ChevronLeft /></button>
        <h2 className="text-lg font-semibold text-zinc-900">{format(currentMonth, 'MMMM yyyy')}</h2>
        <button onClick={nextMonth} className="p-2 active:bg-zinc-100 rounded-full"><ChevronRight /></button>
      </div>

      <div className="grid grid-cols-7 gap-1 mb-2">
        {['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((d, i) => (
          <div key={i} className="text-center text-xs font-semibold text-zinc-400 py-2">
            {d}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-y-2 gap-x-1">
        {days.slice(0, 42).map((day, i) => {
          const isPast = isBefore(day, today);
          const isSelected = selectedDateStr === format(day, 'yyyy-MM-dd');
          const isCurrentMonth = isSameMonth(day, currentMonth);
          const isToday = isSameDay(day, today);
          
          // fake limited slots
          const isLimited = !isPast && (day.getDate() % 5 === 0);

          return (
            <button
              key={i}
              disabled={isPast || !isCurrentMonth}
              onClick={() => handleSelect(day)}
              className={cn(
                "h-12 w-full flex flex-col items-center justify-center rounded-xl font-medium text-sm transition-all relative",
                !isCurrentMonth ? "opacity-0 pointer-events-none" : "",
                isPast ? "text-zinc-300" : "text-zinc-900 hover:bg-zinc-100",
                isSelected ? "bg-brand text-white hover:bg-brand" : "",
                isToday && !isSelected ? "ring-1 ring-brand/30 text-brand" : "",
                isLimited && !isSelected && !isPast ? "bg-red-50 text-red-700" : ""
              )}
            >
               {format(day, 'd')}
               {isLimited && !isSelected && !isPast && <div className="w-1 h-1 rounded-full bg-red-400 absolute bottom-1.5" />}
            </button>
          )
        })}
      </div>
    </div>
  );
}
