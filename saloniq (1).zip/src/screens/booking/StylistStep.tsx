import { useNavigate } from 'react-router-dom';
import { useBookingStore } from '../../store';
import { stylists } from '../../data';
import { cn } from '../../utils';
import { Star } from 'lucide-react';

export default function StylistStep() {
  const navigate = useNavigate();
  const selectedId = useBookingStore(s => s.draft.stylistId);
  const updateDraft = useBookingStore(s => s.updateDraft);

  const handleSelect = (id: string) => {
    updateDraft({ stylistId: id });
    navigate('../date');
  };

  return (
    <div className="p-4 pb-10">
      <div 
        onClick={() => handleSelect('any')}
        className={cn(
          "bg-white border rounded-2xl p-4 flex items-center gap-4 mb-4 cursor-pointer transition-all",
          selectedId === 'any' ? "border-brand ring-1 ring-brand bg-brand/5" : "border-zinc-200"
        )}
      >
        <div className="w-14 h-14 rounded-full bg-zinc-100 flex items-center justify-center">
           <Star className="text-zinc-400" size={24} />
        </div>
        <div>
          <h3 className="font-semibold text-lg text-zinc-900">Any Available</h3>
          <p className="text-zinc-500 text-sm">We'll find the best match for your time</p>
        </div>
      </div>

      <h3 className="text-sm font-semibold text-zinc-900 mt-6 mb-3 px-1">Our Team</h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pb-8">
        {stylists.map(stylist => {
           const isSelected = selectedId === stylist.id;
           return (
             <div 
               key={stylist.id}
               onClick={() => handleSelect(stylist.id)}
               className={cn(
                 "bg-white border rounded-2xl p-4 flex items-center gap-4 cursor-pointer transition-all",
                 isSelected ? "border-brand ring-1 ring-brand bg-brand/5" : "border-zinc-200 hover:border-brand/30"
               )}
             >
               <div className="w-14 h-14 rounded-full bg-brand-light flex items-center justify-center font-bold text-brand shrink-0 text-lg">
                 {stylist.initials}
               </div>
               <div className="flex-1">
                 <div className="flex justify-between items-start">
                   <h3 className="font-semibold text-lg text-zinc-900">{stylist.name}</h3>
                   <div className="flex items-center gap-1 text-sm font-medium text-zinc-700">
                     <Star size={14} className="fill-amber-400 text-amber-400" /> {stylist.rating}
                   </div>
                 </div>
                 <p className="text-zinc-500 text-sm mt-0.5">{stylist.specialization.join(' • ')}</p>
                 <div className="flex items-center gap-2 mt-2">
                   <div className={cn("w-2 h-2 rounded-full", stylist.isAvailableToday ? "bg-green-500" : "bg-amber-500")} />
                   <span className="text-xs text-zinc-600 font-medium">{stylist.isAvailableToday ? 'Free today' : stylist.nextAvailableStr}</span>
                 </div>
               </div>
             </div>
           )
        })}
      </div>
    </div>
  );
}
