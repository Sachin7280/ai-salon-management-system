import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useBookingStore } from '../../store';
import { services, serviceCategories } from '../../data';
import { cn } from '../../utils';
import { Search, Check } from 'lucide-react';

export default function ServiceStep() {
  const navigate = useNavigate();
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  
  const selectedId = useBookingStore(s => s.draft.serviceId);
  const updateDraft = useBookingStore(s => s.updateDraft);

  const filtered = services.filter(s => {
    if (filter !== 'all' && s.categoryId !== filter) return false;
    if (search && !s.name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="p-4 pb-32">
      <div className="relative mb-4">
        <Search className="absolute left-3 top-3.5 text-zinc-400" size={18} />
        <input 
          type="text" 
          placeholder="Search services..." 
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full h-11 pl-10 pr-4 bg-white border border-zinc-200 rounded-xl text-sm outline-none focus:border-brand"
        />
      </div>

      <div className="flex overflow-x-auto gap-2 hide-scrollbar mb-6 -mx-4 px-4">
        {serviceCategories.map(cat => (
          <button
            key={cat.id}
            onClick={() => setFilter(cat.id)}
            className={cn(
               "px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors border",
               filter === cat.id ? "bg-zinc-900 border-zinc-900 text-white" : "bg-white border-zinc-200 text-zinc-600"
            )}
          >
            {cat.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pb-6">
        {filtered.map(service => {
           const isSelected = selectedId === service.id;
           return (
             <div 
               key={service.id}
               onClick={() => updateDraft({ serviceId: service.id })}
               className={cn(
                 "bg-white border rounded-2xl p-4 cursor-pointer relative overflow-hidden transition-all duration-200",
                 isSelected ? "border-brand ring-1 ring-brand bg-brand/5" : "border-zinc-200 hover:border-zinc-300 transform-gpu hover:-translate-y-1 hover:shadow-lg"
               )}
             >
               <div className="pr-8">
                 <h3 className="font-medium text-lg text-zinc-900">{service.name}</h3>
                 <p className="text-zinc-500 text-sm mt-1 mb-2">{service.durationMins} mins • ₹{service.price}</p>
                 <p className="text-zinc-600 text-sm">{service.description}</p>
               </div>
               {isSelected && (
                 <div className="absolute top-4 right-4 text-brand">
                    <div className="w-6 h-6 rounded-full bg-brand flex items-center justify-center">
                      <Check size={14} className="text-white" />
                    </div>
                 </div>
               )}
             </div>
           )
        })}
      </div>

      {selectedId && (
        <div className="fixed md:absolute bottom-0 left-0 right-0 w-full p-4 bg-white border-t border-zinc-100 shadow-[0_-10px_20px_rgba(0,0,0,0.02)] z-10 safe-area-bottom">
           <button onClick={() => navigate('../stylist')} className="w-full bg-brand text-white font-semibold text-lg h-14 rounded-2xl active:scale-95 transition-transform">
             Continue
           </button>
        </div>
      )}
    </div>
  );
}
