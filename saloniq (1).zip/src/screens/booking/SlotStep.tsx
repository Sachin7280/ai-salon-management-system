import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { useBookingStore } from '../../store';
import { generateMockSlots, stylists } from '../../data';
import { cn } from '../../utils';
import { Check, Clock, ChevronDown } from 'lucide-react';

export default function SlotStep() {
  const navigate = useNavigate();
  const draft = useBookingStore(s => s.draft);
  const updateDraft = useBookingStore(s => s.updateDraft);
  
  const [showAll, setShowAll] = useState(false);
  const [flippingCard, setFlippingCard] = useState<string | null>(null);

  if (!draft.date) {
    return <div className="p-8 text-center text-zinc-500">Please select a date first.</div>;
  }

  // Generate slots
  const allSlots = generateMockSlots(draft.date, draft.stylistId === 'any' ? 'st1' : (draft.stylistId || 'st1'), 45);
  const recommendedSlots = allSlots.filter(s => s.isRecommended);
  const otherSlots = allSlots.filter(s => !s.isRecommended);

  const handleSelect = (slotId: string, startTime: string) => {
    setFlippingCard(slotId);
    setTimeout(() => {
      updateDraft({ slotId, startTime });
      navigate('../details');
    }, 600); // Wait for flip animation
  };

  return (
    <div className="p-4 bg-background pb-24">
      <div className="mb-6 px-1">
        <h2 className="text-xl font-bold tracking-tight text-zinc-900 mb-1">AI Recommended</h2>
        <p className="text-zinc-500 text-sm">Best times based on your preferences</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 perspective-800">
        {recommendedSlots.map(slot => {
          const isFlipping = flippingCard === slot.id;
          const stylist = stylists.find(s => s.id === slot.stylistId);

          return (
            <motion.div 
              key={slot.id}
              onClick={() => !isFlipping && handleSelect(slot.id, slot.startTime)}
              animate={{ rotateY: isFlipping ? 180 : 0 }}
              transition={{ duration: 0.4, ease: "easeInOut" }}
              style={{ transformStyle: 'preserve-3d' }}
              className="relative w-full h-[120px] cursor-pointer"
            >
               {/* FRONT */}
               <div className="absolute inset-0 bg-white border border-brand/20 rounded-2xl p-4 backface-hidden shadow-sm flex flex-col justify-between">
                 <div className="flex justify-between items-start">
                    <div className="flex items-center gap-2">
                       <Clock size={16} className="text-brand" />
                       <span className="font-bold text-lg text-zinc-900">{slot.startTime}</span>
                    </div>
                    <div className="px-2.5 py-1 bg-brand text-white text-xs font-bold rounded-lg relative overflow-hidden">
                       <div className="absolute inset-0 bg-white/20 animate-score" />
                       <span className="relative z-10">Best Match</span>
                    </div>
                 </div>
                 
                 <div className="flex items-center gap-3">
                   <div className="w-8 h-8 rounded-full bg-brand-light flex items-center justify-center text-brand font-bold text-xs">{stylist?.initials}</div>
                   <div>
                     <p className="text-sm font-medium text-zinc-900 line-clamp-1">{stylist?.name}</p>
                     <p className="text-xs text-zinc-500">{slot.reason}</p>
                   </div>
                 </div>
               </div>

               {/* BACK */}
               <div 
                 className="absolute inset-0 bg-brand text-white rounded-2xl flex flex-col items-center justify-center backface-hidden rotate-y-180"
               >
                 <Check size={32} className="mb-2" />
                 <span className="font-bold text-lg">Slot Selected</span>
               </div>
            </motion.div>
          );
        })}
      </div>

      <div className="mt-8">
         <button onClick={() => setShowAll(!showAll)} className="w-full flex items-center justify-between p-4 bg-white border border-zinc-200 rounded-2xl font-medium text-zinc-700 active:bg-zinc-50">
           Show all available times
           <motion.div animate={{ rotate: showAll ? 180 : 0 }}><ChevronDown size={20} className="text-zinc-400" /></motion.div>
         </button>

         <AnimatePresence>
           {showAll && (
             <motion.div 
               initial={{ height: 0, opacity: 0 }}
               animate={{ height: "auto", opacity: 1 }}
               exit={{ height: 0, opacity: 0 }}
               className="overflow-hidden mt-2"
             >
               <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-4 gap-2 pt-2">
                 {otherSlots.map((slot, i) => (
                   <motion.div
                     key={slot.id}
                     initial={{ opacity: 0, y: 10 }}
                     animate={{ opacity: 1, y: 0 }}
                     transition={{ delay: i * 0.03 }}
                     onClick={() => !flippingCard && handleSelect(slot.id, slot.startTime)}
                     className={cn(
                       "bg-white border rounded-xl p-3 flex justify-center items-center font-medium text-zinc-700 cursor-pointer active:bg-brand/5 active:border-brand/50",
                       flippingCard === slot.id ? "bg-brand text-white border-brand" : "border-zinc-200"
                     )}
                   >
                     {slot.startTime}
                   </motion.div>
                 ))}
               </div>
             </motion.div>
           )}
         </AnimatePresence>
      </div>

    </div>
  );
}
