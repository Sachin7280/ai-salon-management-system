import { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { useBookingStore, useAppointmentsStore, useMetaStore } from '../../store';
import { services, stylists } from '../../data';
import { generateId } from '../../utils';
import { Check, CalendarIcon, MessageCircle } from 'lucide-react';

export default function ConfirmStep() {
  const navigate = useNavigate();
  const draft = useBookingStore(s => s.draft);
  const clearDraft = useBookingStore(s => s.clearDraft);
  const addAppointment = useAppointmentsStore(s => s.addAppointment);
  const addLog = useMetaStore(s => s.addLog);

  const [confirmed, setConfirmed] = useState(false);
  const [particles] = useState(() => [...Array(40)].map((_, i) => ({
    id: i,
    color: ['#4F46E5', '#10B981', '#F59E0B', '#EF4444'][Math.floor(Math.random() * 4)],
    left: Math.random() * 100 + '%',
    delay: Math.random() * 0.5 + 's',
    rotation: Math.random() * 360 + 'deg',
    size: Math.random() * 8 + 4 + 'px'
  })));

  // Generate a stable booking appointment ID
  const [appointmentId] = useState(() => generateId());
  const addedRef = useRef(false);

  useEffect(() => {
    if (!draft.serviceId || !draft.date || !draft.startTime) {
      return;
    }

    if (addedRef.current) return;
    addedRef.current = true;

    const service = services.find(s => s.id === draft.serviceId)!;
    const stylist = stylists.find(s => s.id === draft.stylistId || s.id === 'st1');

    const endMinutes = parseInt(draft.startTime.split(':')[1]) + service.durationMins;
    const endHours = parseInt(draft.startTime.split(':')[0]) + Math.floor(endMinutes / 60);
    const endTime = `${String(endHours).padStart(2, '0')}:${String(endMinutes % 60).padStart(2, '0')}`;

    const appt = {
      id: appointmentId,
      serviceId: service.id,
      serviceName: service.name,
      stylistId: stylist?.id || 'st1',
      stylistName: stylist?.name || 'Any Stylist',
      date: draft.date,
      startTime: draft.startTime,
      endTime,
      price: service.price,
      status: 'upcoming' as const,
      bookedAt: new Date().toISOString(),
      notes: draft.notes || '',
      whatsappOptIn: true
    };

    addAppointment(appt);
    
    // simulate simple delay then success state
    const timer = setTimeout(() => {
       setConfirmed(true);
       addLog(`✅ Confirmed: ${service.name} on ${draft.date} at ${draft.startTime} with ${stylist?.name || 'Stylist'}`);
    }, 150);

    return () => clearTimeout(timer);
  }, [draft, appointmentId, addAppointment, addLog]);

  // Clean up draft only when unmounting the success page
  useEffect(() => {
    return () => {
      clearDraft();
    };
  }, [clearDraft]);

  if (!draft.serviceId || !draft.date || !draft.startTime) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center bg-background h-screen">
        <h2 className="text-xl font-bold text-zinc-900 mb-2">No active booking session found</h2>
        <button onClick={() => navigate('/app/home')} className="mt-4 bg-brand text-white px-6 py-2 rounded-xl font-medium">
          Go To Home
        </button>
      </div>
    );
  }

  const service = services.find(s => s.id === draft.serviceId)!;
  const stylist = stylists.find(s => s.id === draft.stylistId || s.id === 'st1');

  return (
    <div className="flex flex-col h-full bg-background relative overflow-y-auto">
      {/* Confetti container */}
      {confirmed && (
        <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
          {particles.map(p => (
            <div 
              key={p.id}
              className="absolute top-0 rounded-full"
              style={{
                left: p.left,
                width: p.size,
                height: p.size,
                backgroundColor: p.color,
                transform: `rotate(${p.rotation})`,
                animation: `confettiFall 1.5s ease-out forwards`,
                animationDelay: p.delay
              }}
            />
          ))}
        </div>
      )}

      {/* Main card centered container */}
      <div className="flex-1 p-6 md:p-8 flex flex-col items-center justify-start md:justify-center relative z-10 max-w-xl mx-auto w-full pb-8">
        <motion.div 
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 300, damping: 20 }}
          className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center text-white mb-6 shadow-xl shadow-green-500/20 mt-4"
        >
           <motion.svg 
             viewBox="0 0 24 24" 
             fill="none" 
             stroke="currentColor" 
             strokeWidth="3" 
             strokeLinecap="round" 
             strokeLinejoin="round" 
             className="w-10 h-10"
           >
              <motion.polyline
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                points="20 6 9 17 4 12"
              />
           </motion.svg>
        </motion.div>

        <h2 className="text-3xl font-bold tracking-tight text-zinc-900 mb-2">Booking Confirmed!</h2>
        <p className="text-zinc-500 text-center mb-8">Your appointment has been scheduled successfully.</p>

        <div className="w-full bg-white border border-zinc-200 rounded-3xl p-6 mb-6 shadow-sm">
           <h3 className="font-bold text-xl text-zinc-900 mb-4">{service.name}</h3>
           
           <div className="space-y-3 font-medium text-zinc-700">
             <div className="flex justify-between">
                <span className="text-zinc-500">Stylist</span>
                <span>{stylist?.name || 'Any Stylist'}</span>
             </div>
             <div className="flex justify-between">
                <span className="text-zinc-500">Date</span>
                <span>{new Date(draft.date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric'})}</span>
             </div>
             <div className="flex justify-between">
                <span className="text-zinc-500">Time</span>
                <span>{draft.startTime}</span>
             </div>
             <div className="pt-3 mt-3 border-t border-zinc-100 flex justify-between font-bold text-zinc-900">
                <span>Total Amount</span>
                <span>₹{service.price}</span>
             </div>
           </div>
        </div>

        <div className="perspective-800 w-full mb-8">
           <div className="bg-[#25D366]/10 text-[#25D366] rounded-2xl p-4 flex gap-3 items-center">
              <MessageCircle size={24} className="fill-[#25D366]" />
              <div>
                <p className="font-semibold text-sm">Confirmation sent via WhatsApp</p>
                <p className="text-xs opacity-80 mt-0.5">We'll also send a reminder 2 hours before.</p>
              </div>
           </div>
        </div>

        {/* Dynamic Buttons - Inline and beautifully fitted */}
        <div className="w-full flex flex-col gap-3">
           <button onClick={() => navigate('/app/appointments')} className="w-full bg-zinc-900 text-white font-semibold text-lg h-14 rounded-2xl active:scale-95 transition-transform flex items-center justify-center gap-2 shadow-md shadow-black/10">
             <CalendarIcon size={20} /> View My Bookings
           </button>
           <button onClick={() => navigate('/app/home')} className="w-full bg-zinc-100 text-zinc-700 font-semibold text-lg h-14 rounded-2xl active:scale-95 transition-transform">
             Back to Home
           </button>
        </div>
      </div>
    </div>
  );
}
