import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useProfileStore, useBookingStore } from '../../store';

export default function DetailsStep() {
  const navigate = useNavigate();
  const profile = useProfileStore(s => s.profile);
  const updateDraft = useBookingStore(s => s.updateDraft);
  
  useEffect(() => {
    // Auto-advance if profile exists AND they are returning users.
    // The PRD says "If profile exists: this step is skipped entirely".
    // We just ask for notes. Wait, PRD: "notes for stylist (always shown even for returning users)".
    // Ah, wait: "If profile exists: this step is skipped entirely (auto-advance)."
    // Let's re-read PRD accurately: "Step 5 - Client Details. Only shown if localStorage getItem salon_client is null. If profile exists: this step is skipped entirely... If some fields missing...". Wait, it says later "notes for stylist (always shown even for returning users)". Contradiction? I will show the form but pre-fill if available, and if they have all info, I'll just show "Notes".
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const fd = new FormData(e.target as HTMLFormElement);
    const notes = fd.get('notes') as string;
    
    updateDraft({ notes });
    navigate('../confirm');
  };

  return (
    <div className="p-6 md:p-8 bg-white h-full max-w-xl mx-auto">
      <h2 className="text-2xl font-bold tracking-tight text-zinc-900 mb-6">Almost done</h2>
      
      <form onSubmit={handleSubmit} className="flex flex-col gap-6">
        {!profile && (
          <>
            <div>
              <label className="text-sm font-medium text-zinc-700">Full Name</label>
              <input required name="name" type="text" className="w-full mt-2 h-12 px-4 rounded-xl border border-zinc-200 outline-none focus:border-brand focus:ring-1 focus:ring-brand" />
            </div>

            <div>
              <label className="text-sm font-medium text-zinc-700">Mobile Number</label>
              <div className="flex mt-2">
                <div className="h-12 px-4 bg-zinc-100 flex items-center rounded-l-xl border border-zinc-200 border-r-0 text-zinc-500 font-medium">+91</div>
                <input required name="phone" pattern="^[6-9]\d{9}$" type="tel" className="w-full h-12 px-4 rounded-r-xl border border-zinc-200 outline-none focus:border-brand focus:ring-1 focus:ring-brand" />
              </div>
            </div>
          </>
        )}

        <div>
          <label className="text-sm font-medium text-zinc-700">Add a note for the stylist (Optional)</label>
          <textarea name="notes" rows={3} placeholder="E.g., I have sensitive skin, please use gentle products." className="w-full mt-2 p-4 rounded-xl border border-zinc-200 outline-none focus:border-brand focus:ring-1 focus:ring-brand resize-none" />
        </div>

        {profile && (
          <div className="bg-zinc-50 p-4 rounded-2xl border border-zinc-100 flex items-center gap-3">
             <div className="w-10 h-10 rounded-full bg-brand/10 flex items-center justify-center text-brand font-bold">{profile.name[0]}</div>
             <div>
               <p className="font-medium text-zinc-900">{profile.name}</p>
               <p className="text-zinc-500 text-sm">{profile.phone}</p>
             </div>
          </div>
        )}

        <div className="mt-8">
           <button type="submit" className="w-full bg-brand text-white font-semibold text-lg h-14 rounded-2xl active:scale-95 transition-transform">
             Review Booking
           </button>
        </div>
      </form>
    </div>
  );
}
