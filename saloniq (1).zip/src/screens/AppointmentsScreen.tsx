import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { useAppointmentsStore, useBookingStore, useMetaStore } from '../store';
import { cn } from '../utils';
import { Calendar as CalendarIcon, Clock, X, ChevronRight } from 'lucide-react';

export default function AppointmentsScreen() {
  const navigate = useNavigate();
  const appointments = useAppointmentsStore(s => s.appointments);
  const updateAppointmentStatus = useAppointmentsStore(s => s.updateAppointmentStatus);
  const [tab, setTab] = useState<'upcoming' | 'past'>('upcoming');

  const upcoming = appointments.filter(a => a.status === 'upcoming').sort((a,b) => new Date(`${a.date}T${a.startTime}`).getTime() - new Date(`${b.date}T${b.startTime}`).getTime());
  const past = appointments.filter(a => a.status !== 'upcoming').sort((a,b) => new Date(`${b.date}T${b.startTime}`).getTime() - new Date(`${a.date}T${a.startTime}`).getTime());

  const activeList = tab === 'upcoming' ? upcoming : past;

  // Cancel Sheet State
  const [cancelId, setCancelId] = useState<string | null>(null);
  
  const handleCancelClick = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setCancelId(id);
  };

  return (
    <div className="flex flex-col h-full bg-background pb-20 relative">
      <div className="pt-8 px-5 bg-white shadow-sm z-10 sticky top-0">
        <div className="max-w-4xl mx-auto w-full">
          <h1 className="text-2xl font-bold tracking-tight text-zinc-900 mb-6">My Visits</h1>
          <div className="flex gap-4 border-b border-zinc-200">
            <button 
              onClick={() => setTab('upcoming')}
              className={cn("pb-3 text-sm font-semibold transition-colors relative", tab === 'upcoming' ? "text-brand" : "text-zinc-500")}
            >
              Upcoming
              {tab === 'upcoming' && <motion.div layoutId="tab-indicator" className="absolute bottom-0 left-0 w-full h-[2px] bg-brand" />}
            </button>
            <button 
              onClick={() => setTab('past')}
              className={cn("pb-3 text-sm font-semibold transition-colors relative", tab === 'past' ? "text-brand" : "text-zinc-500")}
            >
              Past & Cancelled
              {tab === 'past' && <motion.div layoutId="tab-indicator" className="absolute bottom-0 left-0 w-full h-[2px] bg-brand" />}
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-5">
        <div className="max-w-4xl mx-auto w-full">
          <AnimatePresence mode="popLayout">
            {activeList.map(appt => (
              <motion.div 
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                key={appt.id} 
                className="bg-white rounded-3xl p-5 mb-4 shadow-sm border border-zinc-200"
              >
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="font-bold text-lg text-zinc-900 border-b border-zinc-100 pb-2 mb-2">{appt.serviceName}</h3>
                    <div className="flex items-center gap-1.5 text-zinc-600 font-medium text-sm">
                      <CalendarIcon size={14} /> {new Date(appt.date).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric'})}
                    </div>
                    <div className="flex items-center gap-1.5 text-zinc-650 font-medium text-sm mt-1.5">
                      <Clock size={14} /> {appt.startTime} – {appt.endTime}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-zinc-900 mb-1">₹{appt.price}</p>
                    {appt.status !== 'upcoming' && (
                      <span className={cn(
                        "px-2 py-0.5 rounded text-xs font-bold uppercase", 
                        appt.status === 'completed' ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                      )}>
                        {appt.status}
                      </span>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center gap-3 pt-3">
                  <div className="w-8 h-8 rounded-full bg-zinc-100 flex items-center justify-center font-bold text-xs">
                    {appt.stylistName.split(' ').map(n=>n[0]).join('')}
                  </div>
                  <p className="font-medium text-zinc-800 text-sm flex-1">{appt.stylistName}</p>
                </div>

                {tab === 'upcoming' ? (
                  <div className="flex gap-2 mt-5">
                    <button onClick={(e) => handleCancelClick(appt.id, e)} className="flex-1 py-2.5 rounded-xl border border-zinc-200 font-medium text-sm text-zinc-700 active:bg-zinc-50">Cancel</button>
                    <button onClick={() => navigate(`/app/reschedule/${appt.id}`)} className="flex-1 py-2.5 rounded-xl bg-zinc-900 text-white font-medium text-sm active:bg-zinc-800">Reschedule</button>
                  </div>
                ) : (
                  <div className="mt-5">
                    <button onClick={() => {
                       const updateDraft = useBookingStore.getState().updateDraft;
                       updateDraft({ serviceId: appt.serviceId, stylistId: appt.stylistId });
                       navigate('/app/book/date');
                    }} className="w-full py-2.5 rounded-xl bg-brand/10 text-brand font-semibold text-sm flex items-center justify-center gap-1 active:bg-brand/20 transition-colors">
                      Book Again <ChevronRight size={16} />
                    </button>
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>

          {activeList.length === 0 && (
            <div className="h-[40vh] flex flex-col items-center justify-center text-center">
              <div className="w-16 h-16 bg-zinc-100 rounded-full flex items-center justify-center mb-4">
                <CalendarIcon className="text-zinc-400" size={24} />
              </div>
              <h3 className="font-bold text-[18px] text-zinc-900 mb-1">No {tab} bookings</h3>
              <p className="text-zinc-500 mb-6 text-sm max-w-[200px]">You don't have any appointments in this list yet.</p>
              <button onClick={() => navigate('/app/book/service')} className="bg-brand text-white font-semibold px-6 py-3 rounded-xl active:scale-95 transition-transform">
                Book an Appointment
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Cancel Bottom Sheet */}
      <AnimatePresence>
        {cancelId && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/40 z-50"
              onClick={() => setCancelId(null)}
            />
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: "spring", stiffness: 400, damping: 30 }}
              className="absolute bottom-0 left-0 w-full bg-white rounded-t-3xl pt-2 pb-safe z-50 shadow-2xl"
            >
               <div className="w-12 h-1.5 bg-zinc-200 rounded-full mx-auto mb-6" />
               <div className="px-6 pb-6">
                 <h2 className="text-xl font-bold text-zinc-900 mb-2">Cancel Appointment</h2>
                 <p className="text-zinc-500 text-sm mb-6">Are you sure you want to cancel this booking? This action cannot be undone.</p>
                 
                 <div className="flex flex-col gap-3">
                   <button 
                     className="w-full bg-red-100 text-red-700 font-semibold py-4 rounded-xl text-lg active:bg-red-200 transition-colors"
                     onClick={() => {
                        updateAppointmentStatus(cancelId, 'cancelled');
                        const addLog = useMetaStore.getState().addLog;
                        addLog(`❌ Cancelled appointment ID: ${cancelId}`);
                        setCancelId(null);
                     }}
                   >
                     Confirm Cancellation
                   </button>
                   <button 
                     onClick={() => setCancelId(null)}
                     className="w-full bg-zinc-100 text-zinc-800 font-semibold py-4 rounded-xl text-lg active:bg-zinc-200 transition-colors"
                   >
                     Keep Appointment
                   </button>
                 </div>
               </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
