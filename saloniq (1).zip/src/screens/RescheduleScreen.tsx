import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAppointmentsStore } from '../store';
import { generateMockSlots } from '../data';
import { ChevronLeft } from 'lucide-react';
import { cn } from '../utils';

export default function RescheduleScreen() {
  const { id } = useParams();
  const navigate = useNavigate();
  const appointments = useAppointmentsStore(s => s.appointments);
  const rescheduleAppointment = useAppointmentsStore(s => s.rescheduleAppointment);
  
  const appt = appointments.find(a => a.id === id);

  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedSlot, setSelectedSlot] = useState<string>('');

  if (!appt) return <div className="p-8 text-center">Appointment not found</div>;

  const slots = selectedDate ? generateMockSlots(selectedDate, appt.stylistId, 45) : [];

  const handleConfirm = () => {
    if (!selectedDate || !selectedSlot) return;
    const slotObj = slots.find(s => s.id === selectedSlot)!;
    rescheduleAppointment(appt.id, selectedDate, slotObj.startTime, slotObj.endTime);
    navigate('/app/appointments');
  };

  return (
    <div className="flex flex-col h-full bg-white relative">
      <div className="h-14 flex items-center justify-between px-4 border-b border-zinc-100">
        <button onClick={() => navigate(-1)} className="p-2 -ml-2 text-zinc-900 active:bg-zinc-100 rounded-full">
          <ChevronLeft size={24} />
        </button>
        <h1 className="font-semibold text-lg flex-1 text-center pr-8">Reschedule</h1>
      </div>

      <div className="flex-1 overflow-y-auto p-4 pb-24">
         <div className="bg-zinc-50 border border-zinc-200 rounded-2xl p-4 mb-6">
           <p className="text-xs font-semibold text-zinc-500 uppercase tracking-widest mb-2">Current Booking</p>
           <h3 className="font-bold text-zinc-900">{appt.serviceName}</h3>
           <p className="text-sm text-zinc-600 mt-1">{appt.date} at {appt.startTime}</p>
         </div>

         <h3 className="text-lg font-bold text-zinc-900 mb-3">Pick new date</h3>
         <input 
           type="date" 
           min={new Date().toISOString().split('T')[0]}
           value={selectedDate}
           onChange={e => {
             setSelectedDate(e.target.value);
             setSelectedSlot('');
           }}
           className="w-full h-14 px-4 rounded-xl border border-zinc-200 outline-none focus:border-brand mb-6"
         />

         {selectedDate && (
           <>
             <h3 className="text-lg font-bold text-zinc-900 mb-3">Available slots</h3>
             <div className="grid grid-cols-2 gap-3 mb-6">
               {slots.map(s => (
                 <button 
                   key={s.id}
                   onClick={() => setSelectedSlot(s.id)}
                   className={cn(
                     "h-12 rounded-xl border font-medium transition-colors",
                     selectedSlot === s.id ? "bg-brand text-white border-brand" : "bg-white border-zinc-200 text-zinc-700 active:bg-zinc-50"
                   )}
                 >
                   {s.startTime}
                 </button>
               ))}
             </div>
           </>
         )}
      </div>

      <div className="absolute bottom-0 left-0 w-full p-4 bg-white border-t border-zinc-100 safe-area-bottom pb-safe+4">
         <button 
           disabled={!selectedDate || !selectedSlot}
           onClick={handleConfirm}
           className="w-full h-14 rounded-xl bg-zinc-900 text-white font-semibold disabled:opacity-50 disabled:active:scale-100 active:scale-95 transition-transform"
         >
           Confirm Changes
         </button>
      </div>
    </div>
  );
}
