import React, { useEffect, useState } from 'react';
import { useProfileStore, useAppointmentsStore } from '../store';
import { serviceCategories, services, stylists, generateMockSlots } from '../data';
import { motion } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import { Calendar, Clock, ArrowRight, User as UserIcon, Maximize2, Minimize2 } from 'lucide-react';
import { cn } from '../utils';

function getGreeting(name: string) {
  const hour = new Date().getHours();
  let greet = "Good morning";
  if (hour >= 12 && hour < 17) greet = "Good afternoon";
  if (hour >= 17) greet = "Good evening";
  return `${greet}, ${name.split(' ')[0]}`;
}

export default function HomeScreen() {
  const profile = useProfileStore(s => s.profile);
  const appointments = useAppointmentsStore(s => s.appointments);
  const navigate = useNavigate();

  const activeAppointments = appointments.filter(a => a.status === 'upcoming').sort((a,b) => new Date(`${a.date}T${a.startTime}`).getTime() - new Date(`${b.date}T${b.startTime}`).getTime());
  const nextAppointment = activeAppointments[0];
  const pastAppointments = appointments.filter(a => a.status !== 'upcoming').slice(0, 2);

  // Full Screen Handler
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
      } else {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        }
      }
    } catch (e) {
      alert("Note: To experience complete Full Screen, please open this applet in a separate browser tab directly!");
    }
  };

  // 3D Tilt Hook
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    setTilt({ x: -(y / rect.height) * 12, y: (x / rect.width) * 12 });
  };

  const todayIso = new Date().toISOString().split('T')[0];
  const suggestedSlots = generateMockSlots(todayIso, 'st1', 45).filter(s => s.isRecommended).slice(0, 3);

  return (
    <div className="flex flex-col p-5 pb-24 md:p-8 md:pt-6 h-full bg-background overflow-y-auto hide-scrollbar">
      {/* Header */}
      <div className="mb-6 flex justify-between items-end w-full">
        <div>
          <h1 className="text-2xl md:text-3xl font-semibold tracking-tight text-zinc-900">{getGreeting(profile?.name || 'Guest')}</h1>
          <p className="text-zinc-500 text-sm mt-1">{new Date().toLocaleDateString('en-US', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
        </div>
        <button 
          onClick={toggleFullscreen}
          className="p-3 bg-white border border-zinc-200 rounded-2xl text-zinc-700 hover:text-brand focus:outline-none hover:border-brand/40 shadow-sm active:scale-95 transition-all"
          title="Toggle Full Screen"
        >
          {isFullscreen ? <Minimize2 size={20} /> : <Maximize2 size={20} />}
        </button>
      </div>

      {/* Main Responsive Grid split for Mobile vs Desktop */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 w-full flex-1">
        
        {/* Left Side: Booking & Upcoming Visit */}
        <div className="md:col-span-7 space-y-8">
          {/* Next Appointment Card */}
          <div className="perspective-800">
            <motion.div 
              onMouseMove={handleMouseMove}
              onMouseLeave={() => setTilt({ x: 0, y: 0 })}
              animate={{ rotateX: tilt.x + 4, rotateY: tilt.y }}
              transition={{ type: "spring", stiffness: 400, damping: 30 }}
              style={{ transformStyle: 'preserve-3d' }}
              className="bg-brand rounded-3xl p-6 text-white shadow-xl shadow-brand/20 relative cursor-pointer"
              onClick={() => nextAppointment ? navigate('/app/appointments') : navigate('/app/book/service')}
            >
               {nextAppointment ? (
                 <>
                    <div className="flex items-start justify-between mb-8" style={{ transform: 'translateZ(20px)' }}>
                      <div>
                        <h2 className="text-2xl font-bold">{nextAppointment.serviceName}</h2>
                        <p className="text-brand-light mt-1 flex items-center gap-2">
                          <UserIcon size={14} /> {nextAppointment.stylistName}
                        </p>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center font-bold">
                        {stylists.find(s => s.id === nextAppointment.stylistId)?.initials || 'ST'}
                      </div>
                    </div>

                    <div className="flex items-end justify-between font-medium" style={{ transform: 'translateZ(30px)' }}>
                       <div>
                         <p className="text-brand-light text-sm mb-1">Date & Time</p>
                         <p>{new Date(nextAppointment.date).toLocaleDateString()} at {nextAppointment.startTime}</p>
                       </div>
                       <div className="text-right">
                         <p className="text-brand-light text-sm mb-1">In 2 days</p>
                       </div>
                    </div>
                    
                    <div className="mt-6 flex gap-2" style={{ transform: 'translateZ(40px)' }}>
                      <button onClick={(e) => { e.stopPropagation(); navigate(`/app/reschedule/${nextAppointment.id}`) }} className="flex-1 bg-white/20 hover:bg-white/30 transition-colors py-2.5 rounded-xl text-sm font-medium">Reschedule</button>
                      <button onClick={(e) => { e.stopPropagation(); navigate('/app/appointments') }} className="flex-1 bg-white hover:bg-zinc-50 transition-colors text-brand py-2.5 rounded-xl text-sm font-semibold">Details</button>
                    </div>
                 </>
               ) : (
                 <div className="text-center py-6" style={{ transform: 'translateZ(20px)' }}>
                   <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                     <Calendar className="text-white" size={24} />
                   </div>
                   <h2 className="text-xl font-bold mb-2">No upcoming visits</h2>
                   <p className="text-brand-light text-sm mb-6">Time for a little self-care?</p>
                   <button onClick={() => navigate('/app/book/service')} className="bg-white text-brand px-6 py-3 rounded-xl font-semibold hover:bg-zinc-100 transition-colors">Book Now</button>
                 </div>
               )}
            </motion.div>
          </div>

          {/* Quick Book */}
          <div>
            <h3 className="text-sm font-semibold text-zinc-900 mb-4 px-1">Quick Book</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 px-1">
               {serviceCategories.filter(c => c.id !== 'all').map(cat => (
                 <button
                   key={cat.id}
                   onClick={() => navigate('/app/book/service')}
                   className="px-4 py-3 bg-white border border-zinc-200 rounded-2xl text-center text-sm font-medium text-zinc-700 hover:border-brand/40 active:bg-zinc-50 transition-colors"
                 >
                   {cat.label}
                 </button>
               ))}
            </div>
          </div>
        </div>

        {/* Right Side: AI Suggestions & Features */}
        <div className="md:col-span-5 space-y-8">
          {/* AI Suggestions */}
          <div>
            <h3 className="text-sm font-semibold text-zinc-900 mb-4 px-1">Good times for you this week</h3>
            <div className="flex flex-col gap-4 px-1">
               {suggestedSlots.map(slot => {
                  const stylist = stylists.find(s => s.id === slot.stylistId);
                  return (
                    <div key={slot.id} onClick={() => navigate('/app/book/service')} className="bg-white border border-zinc-200 rounded-2xl p-4 cursor-pointer hover:border-brand/30 hover:shadow-sm transition-all">
                      <div className="flex justify-between items-start mb-3">
                        <p className="font-semibold text-zinc-900">{slot.startTime} <span className="text-zinc-400 font-normal text-sm">Tomorrow</span></p>
                        <div className="px-2 py-0.5 bg-green-105 text-green-700 text-[10px] font-bold rounded-md uppercase tracking-wide bg-emerald-100">98% Match</div>
                      </div>
                      <p className="text-sm text-zinc-650 mb-1 line-clamp-1">{stylist?.name}</p>
                      <p className="text-xs text-brand bg-brand-light/50 px-2 py-1 rounded-lg inline-block">Matches your usual {profile?.preferences.timeOfDay}</p>
                    </div>
                  );
               })}
            </div>
          </div>

          {/* Business Hours & Info Panel for Desktop */}
          <div className="hidden md:block bg-zinc-50 border border-zinc-150 rounded-3xl p-6">
            <h3 className="font-semibold text-zinc-900 mb-3">Salon Information</h3>
            <div className="space-y-3.5 text-sm text-zinc-600">
              <div className="flex justify-between">
                <span>Monday - Friday</span>
                <span className="font-medium text-zinc-900">9:00 AM - 8:00 PM</span>
              </div>
              <div className="flex justify-between">
                <span>Saturday - Sunday</span>
                <span className="font-medium text-zinc-900">10:00 AM - 6:00 PM</span>
              </div>
              <div className="pt-3 border-t border-zinc-200 text-xs text-zinc-500">
                📞 Call us at (555) 123-4567 or open our integrated AI assistant at the bottom right.
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
