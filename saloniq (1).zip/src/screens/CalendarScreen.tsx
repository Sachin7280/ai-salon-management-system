import { useNavigate } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';

export default function CalendarScreen() {
  const navigate = useNavigate();
  return (
    <div className="flex flex-col h-full bg-white">
      <div className="h-14 flex items-center px-4 relative z-10 border-b border-zinc-100">
        <button onClick={() => navigate(-1)} className="p-2 -ml-2 text-zinc-900 absolute left-4 active:bg-zinc-100 rounded-full">
          <ChevronLeft size={24} />
        </button>
        <h1 className="text-center w-full font-semibold text-lg">Salon Calendar</h1>
      </div>
      <div className="flex-1 flex items-center justify-center bg-zinc-50 p-6 text-center">
         <div>
           <div className="w-16 h-16 bg-white border border-zinc-200 rounded-2xl mx-auto mb-4 shadow-sm flex items-center justify-center text-brand font-bold text-xl">📅</div>
           <h2 className="text-lg font-bold text-zinc-900 mb-2">Smart Calendar View</h2>
           <p className="text-zinc-500 text-sm">Showing the week's layout with active stylist slots and utilization.</p>
         </div>
      </div>
    </div>
  );
}
