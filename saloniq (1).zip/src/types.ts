export type AppointmentStatus = "upcoming" | "completed" | "cancelled";

export type Appointment = {
  id: string;
  serviceId: string;
  serviceName: string;
  stylistId: string;
  stylistName: string;
  date: string; // ISO date "YYYY-MM-DD"
  startTime: string; // "10:30"
  endTime: string; // "11:15"
  price: number;
  status: AppointmentStatus;
  bookedAt: string; // ISO datetime
  notes?: string;
  whatsappOptIn: boolean;
};

export type Service = {
  id: string;
  categoryId: string;
  name: string;
  durationMins: number;
  price: number;
  description: string;
};

export type Stylist = {
  id: string;
  name: string;
  initials: string;
  specialization: string[];
  experienceYears: number;
  rating: number;
  isAvailableToday: boolean;
  nextAvailableStr?: string;
};

export type Slot = {
  id: string;
  startTime: string;
  endTime: string;
  stylistId: string;
  score: number;
  reason: string;
  isRecommended: boolean;
};

export type ClientProfile = {
  id: string;
  name: string;
  phone: string;
  email?: string;
  preferences: {
    timeOfDay: "Morning" | "Afternoon" | "Evening";
    stylistId?: string;
    whatsappOptIn: boolean;
  };
};

export type ChatMessage = {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: string;
};
