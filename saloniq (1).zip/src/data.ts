import { Service, Stylist } from './types';

export const serviceCategories = [
  { id: 'all', label: 'All' },
  { id: 'hair', label: 'Hair' },
  { id: 'skin', label: 'Skin' },
  { id: 'spa', label: 'Spa' },
  { id: 'nails', label: 'Nails' },
  { id: 'bridal', label: 'Bridal' },
] as const;

export const services: Service[] = [
  { id: 's1', categoryId: 'hair', name: 'Classic Haircut', durationMins: 45, price: 800, description: 'Expert consultation, wash, cut and style.' },
  { id: 's2', categoryId: 'hair', name: 'Root Touch Up', durationMins: 60, price: 1200, description: 'Perfect color matching for your roots.' },
  { id: 's3', categoryId: 'hair', name: 'Balayage Color', durationMins: 150, price: 4500, description: 'Premium balayage hair color technique.' },
  { id: 's4', categoryId: 'skin', name: 'Deep Cleansing Facial', durationMins: 60, price: 1500, description: 'Purifying treatment for glowing skin.' },
  { id: 's5', categoryId: 'skin', name: 'Anti-Aging Treatment', durationMins: 90, price: 2800, description: 'Advanced facial to reduce fine lines.' },
  { id: 's6', categoryId: 'spa', name: 'Swedish Massage', durationMins: 60, price: 2000, description: 'Relaxing full body massage.' },
  { id: 's7', categoryId: 'spa', name: 'Deep Tissue Massage', durationMins: 90, price: 3000, description: 'Intensive therapy for muscle tension.' },
  { id: 's8', categoryId: 'nails', name: 'Gel Manicure', durationMins: 45, price: 900, description: 'Long-lasting gel polish with nail care.' },
  { id: 's9', categoryId: 'bridal', name: 'Bridal Makeup', durationMins: 120, price: 12000, description: 'Complete bridal transformation.' },
];

export const stylists: Stylist[] = [
  { id: 'st1', name: 'Aisha Malik', initials: 'AM', specialization: ['Hair', 'Color'], experienceYears: 8, rating: 4.9, isAvailableToday: true },
  { id: 'st2', name: 'Karan Singh', initials: 'KS', specialization: ['Hair', 'Fade'], experienceYears: 5, rating: 4.8, isAvailableToday: false, nextAvailableStr: 'Next free: Mon 3 PM' },
  { id: 'st3', name: 'Neha Sharma', initials: 'NS', specialization: ['Skin', 'Bridal'], experienceYears: 10, rating: 5.0, isAvailableToday: true },
  { id: 'st4', name: 'Riya Das', initials: 'RD', specialization: ['Spa', 'Nails'], experienceYears: 4, rating: 4.7, isAvailableToday: true }
];

// Helper to generate fake slots
export function generateMockSlots(dateIso: string, stylistId: string, durationMins: number): import('./types').Slot[] {
  // deterministic random based on date string and stylist
  const hash = Array.from(dateIso + stylistId).reduce((acc, char) => acc + char.charCodeAt(0), 0);
  
  const baseSlots = [
    { start: '10:00', end: '11:00' },
    { start: '11:30', end: '12:30' },
    { start: '14:00', end: '15:00' },
    { start: '15:30', end: '16:30' },
    { start: '17:00', end: '18:00' }
  ];

  const result = baseSlots.map((time, idx) => ({
    id: `slot-${dateIso}-${stylistId}-${idx}`,
    startTime: time.start,
    endTime: time.end,
    stylistId,
    score: 0.1 * (hash % 10) + (idx === 1 ? 0.3 : 0),
    reason: idx === 1 ? 'Matches your preference' : 'Available',
    isRecommended: idx === 1 || idx === 3
  }));

  return result.sort((a,b) => b.score - a.score); // highest score first
}
