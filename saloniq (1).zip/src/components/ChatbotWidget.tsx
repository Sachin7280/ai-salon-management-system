import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useChatStore, useProfileStore } from '../store';
import { MessageCircle, X, Send, Bot, User } from 'lucide-react';
import { cn } from '../utils';

export default function ChatbotWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { messages, addMessage } = useChatStore(s => s);
  const profile = useProfileStore(s => s.profile);
  
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading, isOpen]);

  const handleSend = async (text: string) => {
    if (!text.trim()) return;
    
    setInput('');
    const userMsg = { id: Date.now().toString(), role: 'user' as const, content: text, timestamp: new Date().toISOString() };
    addMessage(userMsg);
    setIsLoading(true);

    try {
      const res = await fetch('/api/v1/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, userMsg].map(m => ({ role: m.role, parts: [{ text: m.content }] }))
        })
      });
      const data = await res.json();
      
      addMessage({ 
        id: (Date.now() + 1).toString(), 
        role: 'assistant', 
        content: data.reply || "Sorry, I couldn't process that request right now.", 
        timestamp: new Date().toISOString() 
      });
    } catch (e) {
      addMessage({ 
        id: (Date.now() + 1).toString(), 
        role: 'assistant', 
        content: "I'm offline right now. Please try again later.", 
        timestamp: new Date().toISOString() 
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
       <AnimatePresence>
         {!isOpen && (
           <motion.button 
             key="fab"
             initial={{ scale: 0, opacity: 0 }}
             animate={{ scale: 1, opacity: 1 }}
             exit={{ scale: 0, opacity: 0 }}
             onClick={() => setIsOpen(true)}
             className="fixed bottom-[80px] right-4 w-14 h-14 bg-brand rounded-full shadow-lg shadow-brand/30 flex items-center justify-center text-white z-50 animate-bounce-stagger-3"
           >
              <div className="absolute inset-0 rounded-full border-2 border-brand animate-pulse-ring" />
              <MessageCircle size={28} />
           </motion.button>
         )}
       </AnimatePresence>

       <AnimatePresence>
         {isOpen && (
           <motion.div
             key="sheet"
             initial={{ y: '100%', opacity: 0 }}
             animate={{ y: 0, opacity: 1 }}
             exit={{ y: '100%', opacity: 0 }}
             transition={{ type: 'spring', damping: 25, stiffness: 300 }}
             className="fixed bottom-0 left-0 w-full md:w-[400px] md:right-4 md:left-auto md:bottom-4 bg-white md:rounded-3xl rounded-t-3xl shadow-2xl z-50 flex flex-col overflow-hidden border border-zinc-200"
             style={{ height: '75vh', maxHeight: '600px' }}
           >
             {/* Header */}
             <div className="h-16 px-4 bg-zinc-900 flex items-center justify-between shrink-0">
               <div className="flex items-center gap-3">
                 <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center">
                   <Bot size={20} className="text-white" />
                 </div>
                 <div>
                   <h3 className="font-bold text-white text-sm">SalonIQ Assistant</h3>
                   <div className="flex items-center gap-1.5 mt-0.5">
                     <div className="w-2 h-2 rounded-full bg-green-500" />
                     <span className="text-xs text-zinc-400 font-medium">Online</span>
                   </div>
                 </div>
               </div>
               <button onClick={() => setIsOpen(false)} className="w-8 h-8 flex items-center justify-center rounded-full bg-white/10 text-white active:bg-white/20 transition-colors">
                 <X size={18} />
               </button>
             </div>

             {/* Messages */}
             <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 flex flex-col gap-4 bg-[#F8F7F4]">
               {messages.length === 0 && (
                 <div className="text-center py-8">
                   <div className="w-16 h-16 bg-white rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-sm">
                     <span className="text-2xl font-bold text-brand">IQ</span>
                   </div>
                   <h3 className="font-bold text-zinc-900 mb-1">Hi {profile?.name.split(' ')[0] || 'there'}!</h3>
                   <p className="text-sm text-zinc-500 mb-6 px-4">I can help you manage bookings or learn about our services.</p>
                   
                   <div className="flex flex-col gap-2 px-2">
                     {["What are my upcoming appointments?", "Book a haircut for tomorrow", "What services do you offer?"].map((q, i) => (
                       <button
                         key={i}
                         onClick={() => handleSend(q)}
                         className="p-3 bg-white rounded-xl border border-zinc-200 text-sm font-medium text-brand text-left shadow-sm active:bg-brand/5"
                       >
                         {q}
                       </button>
                     ))}
                   </div>
                 </div>
               )}

               {messages.map(msg => {
                 const isUser = msg.role === 'user';
                 return (
                   <div key={msg.id} className={cn("flex gap-2 max-w-[85%]", isUser ? "self-end flex-row-reverse" : "self-start")}>
                     <div className={cn("w-8 h-8 rounded-full flex items-center justify-center shrink-0 mt-auto", isUser ? "bg-zinc-200" : "bg-brand text-white")}>
                       {isUser ? <User size={14} className="text-zinc-600" /> : <Bot size={14} />}
                     </div>
                     <div className={cn("p-3 rounded-2xl text-sm", isUser ? "bg-zinc-900 text-white rounded-br-none" : "bg-white border border-zinc-200 text-zinc-900 rounded-bl-none shadow-sm")}>
                        {msg.content}
                     </div>
                   </div>
                 )
               })}

               {isLoading && (
                 <div className="flex gap-2 self-start max-w-[85%] mt-2">
                   <div className="w-8 h-8 rounded-full bg-brand flex items-center justify-center shrink-0 mt-auto text-white"><Bot size={14} /></div>
                   <div className="p-4 bg-white border border-zinc-200 rounded-2xl rounded-bl-none shadow-sm flex items-center gap-1.5 h-[42px]">
                     <div className="w-1.5 h-1.5 bg-zinc-300 rounded-full animate-bounce-stagger-1" />
                     <div className="w-1.5 h-1.5 bg-zinc-400 rounded-full animate-bounce-stagger-2" />
                     <div className="w-1.5 h-1.5 bg-zinc-500 rounded-full animate-bounce-stagger-3" />
                   </div>
                 </div>
               )}
             </div>

             {/* Input */}
             <div className="p-3 bg-white border-t border-zinc-100 flex gap-2">
               <input 
                 type="text" 
                 value={input}
                 onChange={e => setInput(e.target.value)}
                 onKeyDown={e => e.key === 'Enter' && handleSend(input)}
                 placeholder="Type a message..."
                 className="flex-1 h-12 bg-zinc-100 rounded-full px-4 text-sm outline-none focus:ring-1 focus:ring-brand focus:bg-white transition-colors"
               />
               <button 
                 onClick={() => handleSend(input)}
                 disabled={!input.trim() || isLoading}
                 className="w-12 h-12 rounded-full bg-brand text-white flex items-center justify-center shrink-0 disabled:opacity-50 disabled:cursor-not-allowed"
               >
                 <Send size={18} className="translate-x-[1px] translate-y-[1px]" />
               </button>
             </div>
           </motion.div>
         )}
       </AnimatePresence>
    </>
  );
}
